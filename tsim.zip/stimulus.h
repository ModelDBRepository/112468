/*********************************************************************
 * A specification for the data structure which is used to store
 * information about a given external stimulus applied to the cells.
 * Mike True, 8/20/06
 *********************************************************************/

struct Stimulus
{
    float begin;		//the initiation time of the stimulus
    float end;			//the ending time of the stimulus	
    int lower;			//these are a series of rectangular coordinates
    int upper;			//  that define the area affected by the
    int left;			//  stimulus
    int right; 
    float amp; 			//the strength of stimulus
};

typedef struct Stimulus Stimulus;
